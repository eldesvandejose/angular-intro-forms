import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar/navbar.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [NavbarComponent, HeaderComponent, HomeComponent],
  exports: [NavbarComponent, HeaderComponent, HomeComponent]
})
export class CommonsModule { }
